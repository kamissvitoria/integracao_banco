<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use Illuminate\Http\Request;

class ClienteController extends Controller
{
    public function store ( Request $request)
    {
        $cliente = Cliente::create([
            'nome' => $request->nome,
            'celular'=> $request-> celular,
            'CPF' => $request-> CPF,
            'email' => $request -> email,
            'dataDeNascimento' => $request-> dataDeNascimento,
            'cidade' => $request-> cidade,
            'estado'=> $request-> estado,
            'país' => $request-> país,
            'rua' => $request-> rua,
            'numero'=> $request->numero,
            'bairro' => $request->bairro,
            'CEP' => $request->CEP

        ]);

        return response()->json([
            'status' => true,
            'message' => 'cadastrado',
            'data' => $cliente
        ]);
    }

    public function index()
    {
        $cliente = Cliente::all();

        return response()->json([
        'status'=> true,
        'data' => $cliente
        ]);

    }

    public function update(Request $request)
    {
        $cliente = Cliente::find($request->id);

        if ($cliente == null) {
            return response()->json([
                'status' => false,
                'message' => 'Cliente não encontrado'
            ]);
        }

        if (isset($request->nome)) {
            $cliente->nome = $request->nome;
        }

        if (isset($request->celular)) {
            $cliente->celular = $request->celular;
        }

        if (isset($request->CPF)) {
            $cliente->CPF = $request->CPF;
        }

        if (isset($request->email)) {
            $cliente->email = $request->email;
        }

        if (isset($request->dataDeNascimento)) {
            $cliente->dataDeNascimento = $request->dataDeNascimento;
        }

        if (isset($request->cidade)) {
            $cliente->cidade = $request->cidade;
        }

        if (isset($request->estado)) {
            $cliente->estado = $request->estado;
        }

        if (isset($request->país)) {
            $cliente->país = $request->país;
        }

        if (isset($request->rua)) {
            $cliente->rua = $request->rua;
        }

        if (isset($request->numero)) {
            $cliente->numero = $request->numero;
        }

        if (isset($request->bairro)) {
            $cliente->bairro = $request->bairro;
        }

        if (isset($request->CEP)) {
            $cliente->CEP = $request->CEP;
        }



        $cliente->update();

        return response()->json([
            'status' => true,
            'message' => 'atualizado'
        ]);
    }

    public function delete($id)
    {
        $cliente = Cliente::find($id);

        if ($cliente == null) {
            return response()->json([
                'status' => false,
                'message' => 'cliente não encontrado'
            ]);
        }

        $cliente->delete();

        return response()->json([
            'status' => true,
            'message' => 'excluido'
        ]);
    }


}
